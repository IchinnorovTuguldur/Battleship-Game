//EXTRA CREDIT:Battleship
//Name: Ichinnorov Tuguldur
//  Ship.cpp
//  Battleship

#include "Ship.h"
#include <iostream>
using namespace std;

Ship::Ship(point originPoint, direction o, int l) 
{
  origin.setX(originPoint.getX());
  origin.setY(originPoint.getY());
  orientation = o;
  length = l;

  point temp(origin.getX(), origin.getY());
  // hits remain empty, initialize points
  for (int i = 0; i < length; i++){
      
      if (o == HORIZONTAL)
        temp.setX(origin.getX() + i);
      else   // (o == VERTICAL)
        temp.setY(origin.getY() + i);
      points.add(temp);               
    
  }
  
}


Ship::Ship(const Ship& s) 
{
  *this = s;    // using operator= 
}

//*******************************************************************************************
// Contains Point
//*******************************************************************************************

bool Ship::containsPoint(const point& p) const
{
  return points.contains(p);  // **
    
}

//*******************************************************************************************
// Collides With
//*******************************************************************************************

bool Ship::collidesWith(const Ship& s) const
{
  for (int i = 0; i < length; i++){
    if (s.containsPoint(points.get(i))){     
      return true;
    }
  }
  return false;

}

//*******************************************************************************************
// Shot Fired At Point
//*******************************************************************************************

void Ship::shotFiredAtPoint(const point& p)
{
  if (points.contains(p) && !hits.contains(p))  
    hits.add(p);       
}

//*******************************************************************************************
// Is Hit At Point
//*******************************************************************************************

bool Ship::isHitAtPoint(const point& p)
{
  return hits.contains(p);   
}

//*******************************************************************************************
// Hit Count
//*******************************************************************************************

int Ship::hitCount() const
{ 
  return hits.getSize();
}

//*******************************************************************************************
// Operator =
//*******************************************************************************************

const Ship& Ship::operator=(const Ship& s)
{
  length = s.length;
  orientation = s.orientation;
  origin.setX(s.origin.getX());
  origin.setY(s.origin.getY());
  points = s.points;   
  hits = s.hits;      

	return *this;
}
//*******************************************************************************************
//  Is Sunk
//*******************************************************************************************

bool Ship::isSunk() 
{
  return hitCount() == length; 
}
