//EXTRA CREDIT:Battleship
//Name: Ichinnorov Tuguldur
//  Board.cpp
//  Battleship

#include "Board.h"
#include <cstdlib>  // srand()
#include <ctime>    // time(0)
#include <iostream>
using namespace std;

Ship* Board::generateShipWithLength(int l){

  
  Ship* shipPtr;            
  bool createAgain = true;   

  while (createAgain){
    direction o;
    int originX, originY;
    if (rand() % 2 == 0){   
      o = HORIZONTAL;
      originX = rand() % (10 - (l-1));   
      originY = rand() % (9 - 0 + 1) + 0;
    }
    else {
      o = VERTICAL;
      originY = rand() % (10 - (l-1));
      originX = rand() % (9 - 0 + 1) + 0;
    }
    point originPoint(originX, originY);
    
    shipPtr = new Ship(originPoint, o, l);  
    for (int i = 0; i < 4; i++){
      if ( ships[i] != NULL &&  shipPtr->collidesWith(*ships[i])){
        createAgain = true;
        delete shipPtr;       
        break;                   
        
      }
      else
        createAgain = false;
    }
  }

  return shipPtr;  
}

Board::Board(){       // ****
  
  for (int i = 0; i < 4; i++){
    ships[i] = NULL;   
  }

  // start to generate ship + collidesWith
  for (int i = 0; i < 4; i++){
    ships[i] = generateShipWithLength(5 - i); // ships length 5,4,3,2
                        
  }

}

Board::~Board(){
  for (int i = 0; i < 4; i++)
    delete ships[i];     /// not delete [] ships[i]
    // ships[i] = NULL 
}

bool Board::fireShot(int x, int y){
  bool isHit = false;
  point currentFirePoint(x,y);
  
  // update 4 ships hit(if hit). 
  // if hit update isHit
  for (int i = 0; i < 4; i++){
    ships[i]->shotFiredAtPoint(currentFirePoint); // update hits
    if (ships[i]->isHitAtPoint(currentFirePoint)){
      isHit = true;
      cout << "Hit!\n";
      if (ships[i]->isSunk())
        cout << "You sank a ship with length " << ships[i]->hitCount() << "!\n";
    }
  } 

  // if not hit, update misses
  if (!isHit){
    misses.add(currentFirePoint);               // update misses
    cout << "Miss.\n";
  }
  
  return isHit;
}

int Board::unsunkShipCount(){
  int count = 4;
  for (int i = 0; i < 4; i++){
    if (ships[i]->isSunk())
      count--;
  }
  return count;
}

void Board::display(){      // generate a board[10][10] first better
  
  // creating a initial 2D char array (to represent a board)
  // each with initial value '~'
  char boardArr[10][10];
  for (int i = 0; i < 10; i++)
    for (int j = 0; j < 10; j++)
      boardArr[i][j] = '~';
   
  // the nested for loop to update points to '.' and 'X'
  for (int i = 0; i < 10; i++){
    for (int j = 0; j < 10; j++){
      point currentPoint(i, j);

      // change all misses to '.'
      if (misses.contains(currentPoint)){
        boardArr[i][j] = '.';
      }

      // change all hits in 4 ships to 'X'
      for (int shipIndex = 0; shipIndex < 4; shipIndex++){
        if (ships[shipIndex]->isHitAtPoint(currentPoint)){
          boardArr[i][j] = 'X';
       
        }
      }
    }
  }
  for (int j = 9; j >= 0; j--){     
    cout << j;
    for (int i = 0; i < 10; i++){   
      cout << ' ' << boardArr[i][j];       
    }
    cout << endl;
  }
  cout << "  0 1 2 3 4 5 6 7 8 9" << endl;

}
